# This is a sample Python script.

# Import only system from os
#from os import system, name

#import sys to do an early script exit.
import sys

# Create a 2d list for production scripts listing their file path.
prod_script_list = [
    "Production_Scripts/ssh_client/ssh_client.py",
    "Production_Scripts/build_ip_list_from_directory/build_ip_list_from_directory.py",
    "Production_Scripts/login_ip_list_show_save/login_ip_list_show_save.py",
    "Production_Scripts/login_ip_list_show_search/login_ip_list_show_search.py",
    "Production_Scripts/palo_object_cleanup/palo_object_cleanup.py",
    "Production_Scripts/ping_scan/ping_scan.py",
    "Production_Scripts/list_addresses_from_directory/list_addresses_from_directory.py",
    "Production_Scripts/get_file_names_from_directory/get_file_names_from_directory.py",
    "Production_Scripts/apply_config_to_devices/apply_config_to_devices.py",
]

# Create a 2d list for tutorial scripts listing their file path.
tutorial_script_list = [
    "Tutorial Scripts/hello_world_test/hello_world_test.py",
    "Tutorial Scripts/draw_shape_test/draw_shape_test.py",
    "Tutorial Scripts/variables_test/variables_test.py",
    "Tutorial Scripts/strings_test/strings_test.py",
    "Tutorial Scripts/numbers_test/numbers_test.py",
    "Tutorial Scripts/import_test/import_test.py",
    "Tutorial Scripts/user_input_test/user_input_test.py",
    "Tutorial Scripts/calculator_test/calculator_test.py",
    "Tutorial Scripts/mad_lib_game_test/mad_lib_game_test.py",
    "Tutorial Scripts/lists_test/lists_test.py",
    "Tutorial Scripts/tuples_test/tuples_test.py",
    "Tutorial Scripts/functions_test/functions_test.py",
    "Tutorial Scripts/return_statement_test/return_statement_test.py",
    "Tutorial Scripts/if_statement_test/if_statement_test.py",
    "Tutorial Scripts/advanced_calculator/advanced_calculator_test.py",
    "Tutorial Scripts/dictionaries_test/dictionaries_test.py",
    "Tutorial Scripts/while_loop_test/while_loop_test.py",
    "Tutorial Scripts/guessing_game_test/guessing_game_test.py",
    "Tutorial Scripts/for_loop_test/for_loop_test.py",
    "Tutorial Scripts/exponent_function_test/exponent_function_test.py",
    "Tutorial Scripts/2d_lists_and_nested_loops_test/2d_lists_and_nested_loops_test.py",
    "Tutorial Scripts/build_translator_test/build_translator_test.py",
    "Tutorial Scripts/comments_test/comments_test.py",
    "Tutorial Scripts/try_except_test/try_except_test.py",
    "Tutorial Scripts/gui_test/gui_test.py",
    "Tutorial Scripts/read_file_test/read_file_test.py"
]

# Define our clear function.
def clear():
    # For Windows
    if name == 'nt':
        _ = system('cls')

    # For MAC and Linux (here, os.name is 'posix')
    else:
        _ = system('clear')

def print_main_menu(selection):
    # Print screen heading and options.
    print("MAIN MENU")
    print("Enter e to exit.")
    print("1. Run Production Scripts.")
    print("2. Run Tutorial Scripts.")
    selection = input("Please select an option: ")
    return selection

def print_prod_menu(selection):
    # Print screen heading and options.
    print("PRODUCTION SCRIPTS")
    print("Enter m to return to main menu.")
    print("Enter e to exit.")

    for index in range(len(prod_script_list)):
        print(str(index + 1) + ". " + prod_script_list[index])
    selection = input("Please select an option: ")
    return selection

def print_tutorial_menu(selection):
    # Print screen heading and options.
    print("TUTORIAL SCRIPTS")
    print("Enter m to return to main menu.")
    print("Enter e to exit.")

    for index in range(len(tutorial_script_list)):
        print(str(index + 1) + ". " + tutorial_script_list[index])

    selection = input("Please select an option: ")
    return selection

exit_script = False

while not exit_script:
    main_menu_selection = None
    main_menu_selection = print_main_menu(None)
    if main_menu_selection == "1":
        #clear()
        # Call Prod menu function.
        prod_selection = None
        prod_selection = print_prod_menu(prod_selection)
        if prod_selection != 'm' and prod_selection != 'e':
            try:
                print("Running script " + prod_selection + ". " + prod_script_list[int(prod_selection) - 1])
                exec(open(prod_script_list[int(prod_selection) - 1]).read())
            except:
                print("*****Invalid input. Try again.*****")
        elif prod_selection == 'm':
            main_menu_selection = None
        elif prod_selection == 'e':
            exit_script = True

    elif main_menu_selection == "2":
        #clear()
        # Call Tutorial menu function.
        tutorial_selection = None
        tutorial_selection = print_tutorial_menu(tutorial_selection)
        if tutorial_selection != 'm' and tutorial_selection != 'e':
            try:
                print("Running script " + tutorial_selection + ". " + tutorial_script_list[int(tutorial_selection) - 1])
                exec(open(tutorial_script_list[int(tutorial_selection) - 1]).read())
            except:
                print("*****Invalid input. Try again.*****")
        elif tutorial_selection == 'm':
            main_menu_selection = None
        elif tutorial_selection == 'e':
            exit_script = True
    elif main_menu_selection == 'e':
        exit_script = True
    else:
       print("Please select a valid option.")
