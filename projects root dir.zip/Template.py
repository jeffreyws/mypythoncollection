


def main():
    # Call other functions here

    do_stuff()



def do_stuff():
    # Do stuff
    return None


if __name__ == "__main__":
    main()

