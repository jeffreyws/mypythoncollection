import tkinter as tk
import sys
import os
import subprocess


def main():
   build_interface()


def load_table():
    app_table = [
        ["1001", "Production_Scripts/build_ip_list_from_directory/build_ip_list_from_directory.py"],
        ["1002", "Production_Scripts/login_ip_list_show_save/login_ip_list_show_save.py"],
        ["1003", "Production_Scripts/login_ip_list_show_save/login_ip_list_show_save.py"],
        ["1004", "Production_Scripts/palo_object_cleanup/palo_object_cleanup.py"],
        ["1005", "Production_Scripts/ssh_client/ssh_client.py"],
        ["1006", "Production_Scripts/ping_scan/ping_scan.py"],
        ["1007", "Production_Scripts/list_addresses_from_directory/list_addresses_from_directory.py"],
        ["1008", "Production_Scripts/get_file_names_from_directory/get_file_names_from_directory.py"],
        ["1009", "Production_Scripts/apply_config_to_devices/apply_config_to_devices.py"],
        ["2001", "Tutorial Scripts/hello_world_test/hello_world_test.py"],
        ["2002", "Tutorial Scripts/draw_shape_test/draw_shape_test.py"],
        ["2003", "Tutorial Scripts/variables_test/variables_test.py"],
        ["2004", "Tutorial Scripts/strings_test/strings_test.py"]
    ]
    return app_table



def process_selection(my_table, my_selection):
    
    #Skip first row [1:]: of column headings
    for row in my_table:
        if row[0] == str(my_selection):
            print(f"Found: {row}")
            app_location = row[1]
            return app_location




def run_app(app_location):
    try:
        print("Running script " + app_location)
        if os.path.exists(app_location):
             #with open(app_location) as file:
             #   exec(file.read())
            #Can't use exec() when using diaglogs with tkinter. Use subprocess instead.
            #exec(open(app_location).read())
            subprocess.Popen(['python', app_location])
    except:
        print("*****Failed to open application.*****")




def build_interface():

    root = tk.Tk()
    root.title("Python Applications")
    root.geometry("500x650")
    

    

    root_frame = tk.Frame(root, padx=10, pady=10, relief="groove", borderwidth=2)
    #root_frame.pack(pady=100) # Packs the frame with external padding








    my_frame = tk.Frame(root_frame, bg="lightblue", padx=0, pady=10)
    my_frame.pack(pady=5, anchor=tk.NW, side=tk.TOP)

    # Create a control variable (IntVar for integer values)
    selected_option = tk.IntVar()













    # Production Applications
    # Create radio buttons and associate them with the variable and unique values
    rb1001 = tk.Radiobutton(root, text="build_ip_list_from_directory.py", variable=selected_option, value=1001)
    rb1002 = tk.Radiobutton(root, text="login_ip_list_show_save.py", variable=selected_option, value=1002)
    rb1003 = tk.Radiobutton(root, text="login_ip_list_show_search.py", variable=selected_option, value=1003)
    rb1004 = tk.Radiobutton(root, text="palo_object_cleanup.py", variable=selected_option, value=1004)
    rb1005 = tk.Radiobutton(root, text="ssh_client.py", variable=selected_option, value=1005)
    rb1006 = tk.Radiobutton(root, text="ping_scan.py", variable=selected_option, value=1006)
    rb1007 = tk.Radiobutton(root, text="list_addresses_from_directory.py", variable=selected_option, value=1007)
    rb1008 = tk.Radiobutton(root, text="get_file_names_from_directory.py", variable=selected_option, value=1008)
    rb1009 = tk.Radiobutton(root, text="apply_config_to_devices.py", variable=selected_option, value=1009)

    # Tutorial Applications
    # Create radio buttons and associate them with the variable and unique values
    rb2001 = tk.Radiobutton(root, text="hello_world_test.py", variable=selected_option, value=2001)
    rb2002 = tk.Radiobutton(root, text="draw_shape_test.py", variable=selected_option, value=2002)
    rb2003 = tk.Radiobutton(root, text="variables_test.py", variable=selected_option, value=2003)
    rb2004 = tk.Radiobutton(root, text="cstrings_test.py", variable=selected_option, value=2004)

    prod_header_text = "Production Applications"
    prod_header_label = tk.Label(root, text=prod_header_text, font=("Arial", 20, "bold"), padx=10)
    prod_header_label.pack(pady=10, anchor=tk.NW, side=tk.TOP)


    # Pack the radio buttons
    rb1001.pack(anchor=tk.NW, side=tk.TOP, padx=10)
    rb1002.pack(anchor=tk.NW, side=tk.TOP, padx=10)
    rb1003.pack(anchor=tk.NW, side=tk.TOP, padx=10)
    rb1004.pack(anchor=tk.NW, side=tk.TOP, padx=10)
    rb1005.pack(anchor=tk.NW, side=tk.TOP, padx=10)
    rb1006.pack(anchor=tk.NW, side=tk.TOP, padx=10)
    rb1007.pack(anchor=tk.NW, side=tk.TOP, padx=10)
    rb1008.pack(anchor=tk.NW, side=tk.TOP, padx=10)
    rb1009.pack(anchor=tk.NW, side=tk.TOP, padx=10)

    space1_header_text = "\n\n\n"
    space1_header_label = tk.Label(root, text=space1_header_text)
    space1_header_label.pack(pady=10)

    tutorial_header_text = "Tutorial Applications"
    tutorial_header_label = tk.Label(root, text=tutorial_header_text, font=("Arial", 20, "bold"), padx=10)
    tutorial_header_label.pack(pady=10, anchor=tk.NW, side=tk.TOP)


    # Pack the radio buttons
    rb2001.pack(anchor=tk.NW, side=tk.TOP, padx=10)
    rb2002.pack(anchor=tk.NW, side=tk.TOP, padx=10)
    rb2003.pack(anchor=tk.NW, side=tk.TOP, padx=10)
    rb2004.pack(anchor=tk.NW, side=tk.TOP, padx=10)


    # Optionally, set a default selected option
    selected_option.set(1001)

 

    space2_header_text = "\n\n\n"
    space2_header_label = tk.Label(root, text=space2_header_text)
    space2_header_label.pack(pady=10)

    def get_selection():
   
        my_selection = selected_option.get()
        #print("Selected option:" {my_selection})
        my_table = load_table()
        app_location = process_selection(my_table, my_selection)
        #print("Hello")
        run_app(app_location)

    btn = tk.Button(root, text="Run Application", command=lambda: get_selection())
    btn.pack(anchor=tk.NW, side=tk.TOP, padx=10)
    
    
    root.mainloop()


 







    


if __name__ == "__main__":
    main()