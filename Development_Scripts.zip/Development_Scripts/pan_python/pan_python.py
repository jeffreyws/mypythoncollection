from panos.firewall import Firewall
from panos.network import EthernetInterface
from panos.network import LoopbackInterface
from panos.network import VlanInterface
from panos.network import Layer3Subinterface
from panos.network import AggregateInterface
import time
import xml.etree.ElementTree as ET

def main ():
    fw = Firewall("10.126.85.3", "jsadmin", "Wjeff4952!23456")

    try:
        print("Check for MFA login push")
        fw.refresh_system_info()
        
        print(fw.version)

        # The serial number attribute is now populated
        print(f"Successfully connected to firewall.")
        print(f"Serial Number: {fw.serial}")
        print(f"Platform: {fw.platform}")
        print(f"Version: {fw.version}")
       
    except Exception as e:
        print(f"An error occurred: {e}")

    try:
        # --- 1. Retrieve all Ethernet interfaces ---
        # refreshall() fetches all instances of the class from the device configuration
        ethernet_interfaces = EthernetInterface.refreshall(fw)

        print("Ethernet Interfaces:")
        for interface in ethernet_interfaces:
            print(f"* Name: {interface.name}, Mode: {interface.mode}, IP: {interface.ip}")

        # --- 2. Retrieve all Sub interfaces ---
        # refreshall() fetches all instances of the class from the device configuration
        layer3_sub_interfaces = Layer3Subinterface.refreshall(fw)

        print("Sub Interfaces:")
        for layer3_sub_interface in layer3_sub_interfaces:
            print(f"* Name: {layer3_sub_interface.name}, Mode: {layer3_sub_interface.mode}, IP: {layer3_sub_interface.ip}")

        # --- 3. Retrieve all Loopback interfaces (optional) ---
        loopback_interfaces = LoopbackInterface.refreshall(fw)

        print("\nLoopback Interfaces:")
        for interface in loopback_interfaces:
            print(f"* Name: {interface.name}, IP: {interface.ip}")
    
        #--- 4. Retrieve all VlanInterfaces
        vlan_interfaces = VlanInterface.refreshall(fw)

        print("\nVlan Interfaces:")
        for interface in vlan_interfaces:
            print(f"* Name: {interface.name}, IP: {interface.ip}")

        #--- 5. Retrieve all Aggregate Interfaces
        aggregate_interfaces = AggregateInterface.refreshall(fw)

        print("\nAggregate Interfaces:")
        for interface in aggregate_interfaces:
            print(f"* Name: {interface.name}, IP: {interface.ip}")

    except Exception as e:
            print(f"An error occurred: {e}")

    time.sleep(30)
    interface_details = fw.op('show interface "all"')
    
 
   
    #ET.dump(interface_details)
    
    
    
    
    print(interface_details)

if __name__=="__main__":
    main()