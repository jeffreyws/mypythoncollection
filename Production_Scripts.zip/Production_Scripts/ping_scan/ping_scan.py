import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
import subprocess
import platform
import socket
import queue
import ipaddress

# Detect OS ping command
PING_CMD = ["ping", "-n", "1"] if platform.system().lower() == "windows" else ["ping", "-c", "1"]

# Thread-safe queue for results
result_queue = queue.Queue()


def ping_host(ip):
    """Ping a single IP and resolve hostname if alive."""
    try:
        # Run ping command
        proc = subprocess.run(PING_CMD + [str(ip)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if proc.returncode == 0:
            try:
                hostname = socket.gethostbyaddr(str(ip))[0]
            except socket.herror:
                hostname = "Unknown"
            result_queue.put((str(ip), "Online", hostname))
        #else:
        #    result_queue.put((str(ip), "Offline", ""))
    except Exception as e:
        result_queue.put((str(ip), f"Error: {e}", ""))
    

def worker(ip_list):
    """Thread worker to ping a list of IPs."""
    for ip in ip_list:
        ping_host(ip)

def start_scan():
    """Start scanning in multiple threads."""
    try:
        start_ip = ipaddress.IPv4Address(start_ip_var.get())
        end_ip = ipaddress.IPv4Address(end_ip_var.get())
    except ipaddress.AddressValueError:
        messagebox.showerror("Invalid IP", "Please enter valid IPv4 addresses.")
        return

    if int(end_ip) < int(start_ip):
        messagebox.showerror("Invalid Range", "End IP must be greater than or equal to Start IP.")
        return

    # Clear previous results
    for row in tree.get_children():
        tree.delete(row)

    ip_range = [ipaddress.IPv4Address(ip) for ip in range(int(start_ip), int(end_ip) + 1)]
    num_threads = min(50, len(ip_range))  # Limit threads

    # Split IPs into chunks for threads
    chunk_size = (len(ip_range) + num_threads - 1) // num_threads
    threads = []
    for i in range(num_threads):
        chunk = ip_range[i * chunk_size:(i + 1) * chunk_size]
        t = threading.Thread(target=worker, args=(chunk,), daemon=True)
        threads.append(t)
        t.start()



    # Start UI update loop
    root.after(100, update_results, threads)

def update_results(threads):
    """Update GUI with results from queue."""
    while not result_queue.empty():
        ip, status, hostname = result_queue.get()
        tree.insert("", tk.END, values=(ip, status, hostname))

    if any(t.is_alive() for t in threads):
        root.after(100, update_results, threads)
    else:
        messagebox.showinfo("Scan Complete", "Ping scan finished.")

def export_results():
    """Export results to CSV."""
    file_path = filedialog.asksaveasfilename(defaultextension=".csv",
                                             filetypes=[("CSV Files", "*.csv")])
    if not file_path:
        return
    try:
        with open(file_path, "w") as f:
            f.write("IP Address,Status,Hostname\n")
            for row_id in tree.get_children():
                values = tree.item(row_id)["values"]
                f.write(",".join(values) + "\n")
        messagebox.showinfo("Export Successful", f"Results saved to {file_path}")
    except Exception as e:
        messagebox.showerror("Export Failed", str(e))

# GUI Setup
root = tk.Tk()
root.title("Multithreaded Ping Scanner")
root.geometry("600x400")

frame = ttk.Frame(root, padding=10)
frame.pack(fill=tk.BOTH, expand=True)

ttk.Label(frame, text="Start IP:").grid(row=0, column=0, sticky=tk.W)
start_ip_var = tk.StringVar()
ttk.Entry(frame, textvariable=start_ip_var, width=15).grid(row=0, column=1, padx=5)

ttk.Label(frame, text="End IP:").grid(row=0, column=2, sticky=tk.W)
end_ip_var = tk.StringVar()
ttk.Entry(frame, textvariable=end_ip_var, width=15).grid(row=0, column=3, padx=5)

ttk.Button(frame, text="Start Scan", command=start_scan).grid(row=0, column=4, padx=5)


#var1 = ttk.IntVar()
#c1 = ttk.Checkbutton(frame, text='Show offline IPs',variable=var1, onvalue=1, offvalue=0)
#c1.pack()

ttk.Button(frame, text="Export CSV", command=export_results).grid(row=0, column=5, padx=5)

columns = ("IP Address", "Status", "Hostname")
tree = ttk.Treeview(frame, columns=columns, show="headings")
for col in columns:
    tree.heading(col, text=col)
    tree.column(col, width=150)
tree.grid(row=1, column=0, columnspan=6, pady=10, sticky="nsew")

frame.rowconfigure(1, weight=1)
frame.columnconfigure(5, weight=1)

root.mainloop()
