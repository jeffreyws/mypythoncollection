from tkinter import Tk, Label
from tkinter.filedialog import askopenfilename
from tkinter import filedialog
from datetime import datetime
import os
import sys
##############################################################################################################

def print_main_menu(selection):
    # Print screen heading and options.
    print("Enter e to exit.")
    print("1. Select parent directory to get file names.")
    #print("2. Select parent directory and include subdirectories to get file names.")
    
    selection = input("Please select an option: ")
    
    return selection



def print_second_menu(selection):
    # Print screen heading and options.
    
    print("Enter e to exit.")
    print("1. Include file extensions.")
    print("2. Do not include file extensions.")

    selection = input("Please select an option: ")


    return selection

##############################################################################################################                    

def get_directory_names(source_dir):
    """
    Lists all immediate subdirectories in source_dir and writes their names to output_file.
    """
    try:
        # Get all entries in the directory
        entries = os.scandir(source_dir)
        
        # Filter for directories only and extract their names
        directories = [entry.name for entry in entries if entry.is_dir()]
        
        return directories
    
        # Write directory names to the output file
        #with open(output_file, "w") as f:
         #   for directory_name in directories:
          #      f.write(f"{directory_name}\n")
        
       # print(f"Directory names from '{source_dir}' successfully written to '{output_file}'.")

    except FileNotFoundError:
        print(f"Error: The directory '{source_dir}' was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")





##############################################################################################################


def output_to_file(list_of_directories, output_directory, output_file_name):
    """
    Writes a list of strings to a specified file, each on a new line.
    """
    output_file_path = os.path.join(output_directory, output_file_name)
    with open(output_file_path, 'w') as f:
        for item in list_of_directories:
            f.write(f"{item}\n")








##############################################################################################################


exit_script = False

while not exit_script:
    main_menu_selection = None
    main_menu_selection = print_main_menu(None)

    if main_menu_selection == 'e':
        exit_script = True
    
    elif main_menu_selection != '1' and main_menu_selection != 'e':
        print("Please select a valid option.")
        exit_script = True

    else:
        second_menu_selection = None
        second_menu_selection = print_second_menu(None)
        
        if second_menu_selection == 'e':
                exit_script = True

        elif second_menu_selection == "1" or second_menu_selection =='2':

            directory_window = Tk()
            directory_window.attributes('-topmost', True)
            directory_window.withdraw() # we don't want a full GUI, so keep the root window from appearing
            #Tk().withdraw() # we don't want a full GUI, so keep the root window from appearing
            
            # Example usage:
            target_directory = filedialog.askdirectory()

            #list_of_directories = get_directory_names(target_directory)

            #list_of_file_names = [entry.name for entry in os.scandir(target_directory) if entry.is_file()]
            #print(files)

            files_to_exclude = {'__FolderData__.ini'} # Use a set for faster lookups
            
            list_of_file_names = [
                name for name in os.listdir(target_directory)
                if os.path.isfile(os.path.join(target_directory, name)) and name not in files_to_exclude
            ]
            #if os.path.isfile:
            #    os.path.isfile(os.path)
            #file_names_without_extension = [os.path.splitext(file)[0] for file in file_list]

            #files_no_ext = [".".join(f.split(".")[:-1]) for f in os.listdir() if os.path.isfile(f)]


            if target_directory: #If dialog not canceled
                
                current_datetime = datetime.now()    

                output_directory = "Production_Scripts/get_file_names_from_directory/output"
                os.makedirs(output_directory, exist_ok=True)
                    
                output_file_name = "file-names-output-" + current_datetime.strftime("%m-%d-%Y-%H-%M-%S") + ".txt"
            
                if second_menu_selection == "1":
                    output_to_file(list_of_file_names, output_directory, output_file_name)
                    print(f"Directory names from '{target_directory}' successfully written to '{output_file_name}'.")
            
                elif second_menu_selection == "2":
                    list_of_file_names = [os.path.splitext(file_name)[0] for file_name in list_of_file_names]
                    output_to_file(list_of_file_names, output_directory, output_file_name)
                    print(f"Directory names from '{target_directory}' successfully written to '{output_file_name}'.")
                
                elif second_menu_selection == 'e':
                    exit_script = True
                
                else:
                    print("Please select a valid option.")

        else:
            print("Please select a valid option.")
            exit_script = True



