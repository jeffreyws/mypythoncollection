import sys
from netmiko import Netmiko
from datetime import datetime
from tkinter import filedialog
import tkinter as tk
import time
import os

# --- User Configuration ---
#IP_FILE = "device_ips.txt"
SEARCH_STRING = "interface Loopback0" # Example string to search for
USERNAME = "jsadmin"
PASSWORD = "Wjeff4952!123456"
DEVICE_TYPE = "cisco_ios" # Change based on your device vendor (e.g., juniper, arista_eos)
# --------------------------

def check_config_for_string(device_ip):
    """Connects to a device and checks its config for a specific string."""
    device_info = {
        'device_type': DEVICE_TYPE,
        'ip': device_ip,
        'username': USERNAME,
        'password': PASSWORD,
        'secret': PASSWORD, # For enable mode
        'conn_timeout': 20
    }
    
    try:
        print(f"Connecting to {device_ip.strip()}...")
        net_connect = Netmiko(**device_info)
        net_connect.enable() # Enter enable mode if needed

        print(f"Retrieving configuration from {device_ip.strip()}...")
        # Use a command to get the configuration, e.g., 'show running-config' for Cisco
        output = net_connect.send_command("show running-config")
        
        if SEARCH_STRING in output:
            print(f"[SUCCESS] String '{SEARCH_STRING}' found on {device_ip.strip()}")
        else:
            print(f"[NOT FOUND] String '{SEARCH_STRING}' not found on {device_ip.strip()}")
            
        net_connect.disconnect()
        
    except Exception as e:
        print(f"[ERROR] Could not connect to or retrieve config from {device_ip.strip()}: {e}")








def open_ip_list_file_dialog():
    """Opens a file dialog and prints the selected file path."""
    # Create a Tkinter root window (hidden)
    root = tk.Tk()
    root.wm_attributes('-topmost', 1)
    root.withdraw()  # Hide the main window

    # Open the ip list file dialog
    ip_list_file_path = filedialog.askopenfilename(
        parent=root,
        title="Select an IP list file",
        filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
    )

    # Check if a file was selected
    if ip_list_file_path:
        print(f"Selected file: {ip_list_file_path}")
        # You can now use file_path to open and process the file
        try:
            # Read IP addresses from a file
            with open(ip_list_file_path, 'r') as f:
                ip_list = [line.strip() for line in f if line.strip()]
        except Exception as e:
            print(f"Error reading file: {e}")
    else:
        print("No file selected.")
 
    root.destroy()

    return ip_list






def main():
    """Reads IP addresses from a file and runs the check function."""
    
    ip_list_filename = open_ip_list_file_dialog()
    
    try:
        with open(ip_list_filename, 'r') as f:
            devices = f.readlines()
            for device_ip in devices:
                check_config_for_string(device_ip.strip())
    except FileNotFoundError:
        print(f"Error: The file {ip_list_filename} was not found.")
        sys.exit(1)

if __name__ == "__main__":
    main()
