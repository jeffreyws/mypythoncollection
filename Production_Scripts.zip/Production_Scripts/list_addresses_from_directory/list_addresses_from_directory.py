from tkinter import Tk, Label
from tkinter.filedialog import askopenfilename
from tkinter import filedialog
from datetime import datetime
import os
import sys
##############################################################################################################

def print_main_menu(selection):
    # Print screen heading and options.
    print("Enter e to exit.")
    print("1. Select parent directory to get subdirectory names.")
    #print("2. Select file with IP list.")
    selection = input("Please select an option: ")
    return selection

##############################################################################################################                    

def get_directory_names(source_dir):
    """
    Lists all immediate subdirectories in source_dir and writes their names to output_file.
    """
    try:
        # Get all entries in the directory
        entries = os.scandir(source_dir)
        
        # Filter for directories only and extract their names
        directories = [entry.name for entry in entries if entry.is_dir()]
        
        return directories
    
        # Write directory names to the output file
        #with open(output_file, "w") as f:
         #   for directory_name in directories:
          #      f.write(f"{directory_name}\n")
        
       # print(f"Directory names from '{source_dir}' successfully written to '{output_file}'.")

    except FileNotFoundError:
        print(f"Error: The directory '{source_dir}' was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")





##############################################################################################################


def output_to_file(list_of_directories, output_directory, output_file_name):
    """
    Writes a list of strings to a specified file, each on a new line.
    """
    output_file_path = os.path.join(output_directory, output_file_name)
    with open(output_file_path, 'w') as f:
        for item in list_of_directories:
            f.write(f"{item}\n")








##############################################################################################################


exit_script = False

while not exit_script:
    main_menu_selection = None
    main_menu_selection = print_main_menu(None)
    
    if main_menu_selection == "1":

        directory_window = Tk()
        directory_window.attributes('-topmost', True)
        directory_window.withdraw() # we don't want a full GUI, so keep the root window from appearing
        #Tk().withdraw() # we don't want a full GUI, so keep the root window from appearing
        
        # Example usage:
        target_directory = filedialog.askdirectory()

        list_of_directories = get_directory_names(target_directory)

        if target_directory: #If not dialog not canceled
            
            current_datetime = datetime.now()    

            output_directory = "Production_Scripts/list_addresses_from_directory/output"
            os.makedirs(output_directory, exist_ok=True)
                
            output_file_name = "address-list-output-" + current_datetime.strftime("%m-%d-%Y-%H-%M-%S") + ".txt"
            
            output_to_file(list_of_directories, output_directory, output_file_name)

            print(f"Directory names from '{target_directory}' successfully written to '{output_file_name}'.")
            
        else: #if dialog canceled
            exit_script = True
    

    #elif main_menu_selection == "2":
    #    print("temp")
    elif main_menu_selection == 'e':
        exit_script = True

    else:
        print("Please select a valid option.")




