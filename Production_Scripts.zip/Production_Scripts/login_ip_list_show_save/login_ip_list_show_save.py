
from netmiko import ConnectHandler
from datetime import datetime
from tkinter import filedialog
import tkinter as tk
import paramiko
import getpass
import time
import os
import sys

#if __name__ == '__main__':
#    main()

def main():
    # Call other functions here
        ip_list = []
        command_list = []

        ip_list = open_ip_list_file_dialog()
        command_list = open_commands_list_file_dialog()

        username = input("Enter username: ")
        password = getpass.getpass("Enter password: ")

        run_commands(ip_list, command_list, username, password)

def run_commands(ip_list, command_list, username, password):

    for ip in ip_list:
        all_output = ""
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            client.connect(ip, 22, username, password)
            print(f"Connected to {ip}")
            commands_shell = client.invoke_shell()

            commands_shell.send(f"term len 0\n")
            
            print(f"Running commands for {ip}")

            for command in command_list:
                commands_shell.send(f"{command}\n")
                time.sleep(2)  # Give time for command execution and output
                output = commands_shell.recv(65535).decode('utf-8').replace('\r', '')
                
                #print(f"Output from {ip} for command '{command}':\n{output}")
                all_output += output
                #send_to_file(output, ip)
                #clean_output = all_output.rstrip
            send_to_file(all_output, ip)
        except paramiko.AuthenticationException:
            print(f"Authentication failed for {ip}")
        except paramiko.SSHException as e:
            print(f"SSH error connecting to {ip}: {e}")
        except Exception as e:
            print(f"An error occurred with {ip}: {e}")
        finally:
            if client:
                client.close()


def send_to_file(output, device_ip):
    current_datetime = datetime.now()  
    script_dir = os.path.dirname(os.path.realpath(__file__))
    subdirectory = script_dir + "/output/"
    os.makedirs(subdirectory, exist_ok=True)
    
    file_name = device_ip + "-output-" + current_datetime.strftime("%m-%d-%Y-%H-%M-%S") + ".txt"
    file_path = os.path.join(subdirectory, file_name)

    with open(file_path, 'w') as f:
     f.write(output)
    


def open_ip_list_file_dialog():
    """Opens a file dialog and prints the selected file path."""
    # Create a Tkinter root window (hidden)
    root = tk.Tk()
    root.wm_attributes('-topmost', 1)
    root.withdraw()  # Hide the main window

    # Open the ip list file dialog
    ip_list_file_path = filedialog.askopenfilename(
        parent=root,
        title="Select an IP list file",
        filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
    )

    # Check if a file was selected
    if ip_list_file_path:
        print(f"Selected file: {ip_list_file_path}")
        # You can now use file_path to open and process the file
        try:
            # Read IP addresses from a file
            with open(ip_list_file_path, 'r') as f:
                ip_list = [line.strip() for line in f if line.strip()]
        except Exception as e:
            print(f"Error reading file: {e}")
    else:
        print("No file selected.")
        sys.exit(0)
 
    root.destroy()

    return ip_list


def open_commands_list_file_dialog():

    """Opens a file dialog and prints the selected file path."""
    # Create a Tkinter root window (hidden)
    root2 = tk.Tk()
    root2.wm_attributes('-topmost', 1)
    root2.withdraw()  # Hide the main window

   # Open the commands file dialog
    commands_list_file_path = filedialog.askopenfilename(
        parent=root2,
        title="Select a commands list file",
        filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
    )



 # Check if a file was selected
    if commands_list_file_path:
        print(f"Selected file: {commands_list_file_path}")
        # You can now use file_path to open and process the file
        try:
            # Read IP addresses from a file
            with open(commands_list_file_path, 'r') as f:
                command_list = [line.strip() for line in f if line.strip()]
        except Exception as e:
            print(f"Error reading file: {e}")
    else:
        print("No file selected.")
        sys.exit(0)
   
    root2.destroy()
    
    return command_list

if __name__ == "__main__":
    main()

