from netmiko import ConnectHandler
import getpass
from datetime import datetime
import os

# Device parameters
device = {
    "device_type": "cisco_ios",

    "ip": input("Enter device IP: "),  # Replace with your switch's IP address
    "username": input("Enter username: "),
    "password": getpass.getpass("Enter password: "),
    "secret": getpass.getpass("Enter enable password (if applicable): "),


    # "ip": "10.126.85.8",
    # "username": "jsadmin",
    # "password": "Wjeff4952@123456",
    # "secret": "",

}

try:
    # Establish SSH connection
    net_connect = ConnectHandler(**device)
    print(f"Successfully connected to {device['ip']}")

    # Enter enable mode if needed
    net_connect.enable()


    # Execute show commands
    output_version = net_connect.send_command("show version")
    print("\n--- Show Version Output ---")
    print(output_version)
    # Get the current date and time
    current_datetime = datetime.now()    


    subdirectory = "Production_scripts/ssh_client/output"
    os.makedirs(subdirectory, exist_ok=True)
    
    file_name = device['ip'] + "-output-" + current_datetime.strftime("%m-%d-%Y-%H-%M-%S") + ".txt"

    file_path = os.path.join(subdirectory, file_name)

    with open(file_path, 'w') as f:
     f.write(output_version)
    

    output_interface = net_connect.send_command("show ip interface brief")
    print("\n--- Show IP Interface Brief Output ---")
    print(output_interface)
    with open(file_path, 'a') as f:
       f.write(output_interface)

except Exception as e:
    print(f"An error occurred: {e}")

finally:
    # Disconnect from the device
    if 'net_connect' in locals() and net_connect.is_alive():
        net_connect.disconnect()
        print("Disconnected from the device.")

