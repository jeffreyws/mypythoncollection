#Select file with list of existing objects or address groups. This must be exported from the Palo firewall.
#Select file including firewall configuration. This must be exported from the Palo firewall.

from collections import Counter
import re
from datetime import datetime
from tkinter import filedialog
import tkinter as tk
import time
import os


def count_words_in_file(object_list_file_path, config_file_path):
    """
    Reads a list of words from one file and counts their occurrences in another file.

    Args:
        search_words_file (str): Path to the file containing the list of words to search.
        target_file (str): Path to the file to be searched.

    Returns:
        dict: A dictionary where keys are the search words and values are their counts.
    """



    
    # 1. Read the list of words to search
    try:
        with open(object_list_file_path, 'r', encoding='utf-8') as f:
            search_words = {word.strip() for word in f if word.strip()}
    except FileNotFoundError:
        print(f"Error: Search words file '{object_list_file_path}' not found.")
        return {}

    # Initialize a Counter for the search words
    word_counts = Counter({word: 0 for word in search_words})

    # 2. Process the secondary file
    try:
        with open(config_file_path, 'r', encoding='utf-8') as f:
            for line in f:
                # Convert line to lowercase and split into words
                #words_in_line = re.findall(r'\b.+\b', line)
                words_in_line = re.findall(r'\b[\w\-\.\s]+\b', line)
                # 3. Count occurrences
                for word in words_in_line:
                    if word in search_words:
                        word_counts[word] += 1
    except FileNotFoundError:
        print(f"Error: Target file '{config_file_path}' not found.")
        return {}

    return word_counts






def send_to_file(output):
    current_datetime = datetime.now()  
    subdirectory = "Production_Scripts/palo_object_cleanup/output"
    os.makedirs(subdirectory, exist_ok=True)
    
    file_name = "output-" + current_datetime.strftime("%m-%d-%Y-%H-%M-%S") + ".txt"
    file_path = os.path.join(subdirectory, file_name)

    with open(file_path, 'w') as f:
        f.write(output)
    return






def open_object_list_file_dialog():
    """Opens a file dialog and prints the selected file path."""
    # Create a Tkinter root window (hidden)
    root = tk.Tk()
    root.wm_attributes('-topmost', 1)
    root.withdraw()  # Hide the main window

    # Open the ip list file dialog
    object_list_file_path = filedialog.askopenfilename(
        parent=root,
        title="Select a file with a list of existing objects",
        filetypes=[("All files", "*.*")]
        
    )

 # Check if a file was selected
    if object_list_file_path:
        print(f"Selected file: {object_list_file_path}")
        # You can now use file_path to open and process the file
        try:
            # Read IP addresses from a file
            with open(object_list_file_path, 'r') as f:
               object_list = [line.strip() for line in f if line.strip()]
        except Exception as e:
            print(f"Error reading file: {e}")
    else:
        print("No file selected.")

    root.destroy()

    return object_list_file_path




def open_config_file_dialog():
    """Opens a file dialog and prints the selected file path."""
    # Create a Tkinter root window (hidden)
    root2 = tk.Tk()
    root2.wm_attributes('-topmost', 1)
    root2.withdraw()  # Hide the main window

    # Open the ip list file dialog
    config_file_path = filedialog.askopenfilename(
        parent=root2,
        title="Select the firewall configuration file to search",
        filetypes=[("All files", "*.*")]
    )

    # Check if a file was selected
    if config_file_path:
        print(f"Selected file: {config_file_path}")
        # You can now use file_path to open and process the file
        try:
            # Read IP addresses from a file
            with open(config_file_path, 'r') as f:
               config_file_contents = [line.strip() for line in f if line.strip()]
        except Exception as e:
            print(f"Error reading file: {e}")
    else:
        print("No file selected.")
 
    root2.destroy()

    return config_file_path

    

def main():

    search_list_filename = open_object_list_file_dialog()
    secondary_filename = open_config_file_dialog()

    # Create dummy files for demonstration
    #with open(search_list_filename, 'w') as f:
    #    f.write("apple\norange\nbanana\n")

    #with open(secondary_filename, 'w') as f:
    #    f.write("This document contains an apple and an orange. \n")
    #    f.write("Another line with a banana and another apple.\n")
    #    f.write("No fruits here.\n")

    # Perform the word counting
    results = count_words_in_file(search_list_filename, secondary_filename)

    # 4. Report the counts
    print_list = []
    if results:
        #print("Word counts:")
        for word, count in results.items():
            if count < 2:
               print_list.append (word + ", count = " + str(count))
               #print(f"'{word}': {count}")
        separator = "\r"
        print_string = separator.join(map(str, print_list))
        send_to_file(print_string)




if __name__ == "__main__":
    main()