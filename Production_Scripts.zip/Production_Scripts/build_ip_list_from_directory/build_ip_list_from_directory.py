from tkinter import Tk, Label
from tkinter.filedialog import askopenfilename
from tkinter import filedialog
from datetime import datetime
import os
import sys
##############################################################################################################

def print_main_menu(selection):
    # Print screen heading and options.
    print("Enter e to exit.")
    print("1. Select SecureCRT directory to search.")
    print("2. Select file with IP list.")
    selection = input("Please select an option: ")
    return selection

##############################################################################################################

def search_string_in_directory(directory_path, search_string):
   for dirpath, dirnames, filenames in os.walk(directory_path):
       for filename in filenames:
   # for filename in os.listdir(directory_path):
            filepath = os.path.join(dirpath, filename)

            # Check if it's a file and not a directory
           # if os.path.isfile(filepath):
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                    if search_string in content:
                        print(f"Found '{search_string}' in file: {filename}")
            except Exception as e:
                print(f"Error reading file {filepath}: {e}")

##############################################################################################################                    

def search_and_save(directory_path, search_string, output_file_path):
    """
    Recursively searches for a string in files within a directory,
    parses the matching lines, and saves them to an output file.

    Args:
        directory_path (str): The path to the directory to search.
        search_string (str): The string to search for within files.
        output_file_path (str): The path to the file where results will be saved.
    """
    with open(output_file_path, 'w') as outfile:
        for root, _, files in os.walk(directory_path):
            for filename in files:
                filepath = os.path.join(root, filename)
                try:
                    with open(filepath, 'r', encoding='utf-8', errors='ignore') as infile:
                        for line_num, line in enumerate(infile, 1):
                            if search_string in line:
                                # Example parsing: extract content after the search string
                                # You can customize this parsing logic based on your needs
                                parsed_content = line.strip().split(search_string, 1)[-1].strip()
                                if parsed_content != "":
                                    outfile.write(f"{parsed_content}\n")
                except Exception as e:
                    print(f"Error processing {filepath}: {e}")




##############################################################################################################






exit_script = False

while not exit_script:
    main_menu_selection = None
    main_menu_selection = print_main_menu(None)
    if main_menu_selection == "1":

        directory_window = Tk()
        directory_window.attributes('-topmost', True)
        directory_window.withdraw() # we don't want a full GUI, so keep the root window from appearing
        #Tk().withdraw() # we don't want a full GUI, so keep the root window from appearing
        
        # Example usage:
        target_directory = filedialog.askdirectory()
        if target_directory: #If not dialog not canceled
            
            string_to_find = 'S:"Hostname"='  # Replace with the string you want to find

            search_string_in_directory(target_directory, string_to_find)


            current_datetime = datetime.now()    


            subdirectory = "Production_Scripts/build_ip_list_from_directory/output/"
            os.makedirs(subdirectory, exist_ok=True)
                
            file_name = "device-inventory-output-" + current_datetime.strftime("%m-%d-%Y-%H-%M-%S") + ".txt"
            full_path = subdirectory + file_name

          
            search_and_save(target_directory, string_to_find, full_path)
        else: #if dialog canceled
            exit_script = True
    

    elif main_menu_selection == "2":
        print("temp")
    elif main_menu_selection == 'e':
        exit_script = True

    else:
        print("Please select a valid option.")















