import difflib
import sys
from tkinter import filedialog
import tkinter as tk
   

def print_main_menu():
    # Print screen heading and options.
    print("MAIN MENU")
    print("Enter e to exit.")
    print("1. Do symmetrical comparison of files.")
    print("2. Do asymmetrical comparison of files.")
    selection = input("Please select an option: ")
    return selection



def open_file_dialog(file_number):
    """Opens a file dialog and prints the selected file path."""
    # Create a Tkinter root window (hidden)
    root = tk.Tk()
    root.wm_attributes('-topmost', 1)
    root.withdraw()  # Hide the main window

    # Open the ip list file dialog
    file_path = filedialog.askopenfilename(
        parent=root,
        title=f"Select file {file_number}.",
        filetypes=[("All files", "*.*")]
    )

    # Check if a file was selected
    if file_path:
        print(f"Selected file: {file_path}")
        # You can now use file_path to open and process the file
        try:
            # Read IP addresses from a file
            with open(file_path, 'r') as f:
               config_file_contents = [line.strip() for line in f if line.strip()]
        except Exception as e:
            print(f"Error reading file: {e}")
    else:
        print("No file selected.")
 
    root.destroy()

    return file_path


def print_diff_with_line_numbers(text1_lines, text2_lines, fromfile='', tofile=''):
    """
    Prints a unified diff and manually tracks the line numbers for differences.
    """
    diff_generator = difflib.unified_diff(
        text1_lines, text2_lines, fromfile=fromfile, tofile=tofile, lineterm=''
    )


def process_symmetrical_comparison(file1_path, file2_path):
    with open(file1_path, 'r') as f1, open(file2_path, 'r') as f2:
        file1_lines = f1.readlines()
        file2_lines = f2.readlines()

    diff = difflib.unified_diff(
        file1_lines, file2_lines, fromfile=file1_path, tofile=file2_path, n=0, lineterm='\n'
    )
    #for line in diff:
    #    print(line)

    old_line_num = 0
    new_line_num = 0

    for line in diff:
        # The first two lines are file headers and the third is the control line
        if line.startswith('---') or line.startswith('+++'):
            print(line)
            continue
        
        if line.startswith('@@'):
            # Parse the line number information from the control line
            # Format is @@ -old_start,old_count +new_start,new_count @@
            parts = line.split()
            old_info = parts[1].split(',')
            new_info = parts[2].split(',')
            # Extract the starting line numbers, subtracting 1 for 0-based indexing in code logic
            old_line_num = int(old_info[0].strip('-')) - 1
            new_line_num = int(new_info[0].strip('+')) - 1
            print(line)
            continue

        # Process content lines and track line numbers
        if line.startswith('-'):
            # Deletion from the old file
            old_line_num += 1
            print(f"File 1 Line {old_line_num} is missing in file 2 --- {line.strip()}\n\n")
       # elif line.startswith('+'):
            # Addition to the new file
            #new_line_num += 1
            #print(f"File 2 Line {new_line_num} is missing in file 1 --- {line.strip()}")
        elif line.startswith(' '):
            # Common line (context)
            old_line_num += 1
            new_line_num += 1
            print(line)
        #else:
            # Handle potential special markers (like '\ No newline at end of file')
            #print(line)




def process_asymmetrical_comparison(file1_path, file2_path):
    """
    Checks if each line in file1 exists in file2.

    Args:
        file1_path (str): The path to the file containing lines to check.
        file2_path (str): The path to the file to search within.
    """
    with open(file1_path, 'r') as f1, open(file2_path, 'r') as f2:
        file1_lines = f1.readlines()
        file2_lines = f2.readlines()
    
    try:
        # Read all lines from file2 into a set for efficient lookups
        #with open(file2_path, 'r') as file2:
            # Use strip() to remove leading/trailing whitespace, including newlines
            #file2_lines = set(line.strip() for line in file2)

        print(f"--- Checking lines from '{file1_path}' against '{file2_path}' ---")
        all_lines_present = True
        missing_lines = []

        # Iterate through each line in file1 and check if it is in the set
        with open(file1_path, 'r') as file1:
            for line_num1, line1 in enumerate(file1, 1):
                #stripped_line = line.strip()
                if line1 not in file2_lines:
                    print(f"File 1 Line {line_num1} is missing in file 2 --- {line1}")
                    missing_lines.append(line1)
                    all_lines_present = False
                #else:
                #    print(f"Line {line_num}: '{stripped_line}' is present.")

        if all_lines_present:
            print("\n**Conclusion:** All lines from file 1 were found in file 2.\n")
        #else:
            #print(f"\n**Conclusion:** Some lines were missing from file 2.\n")
            #print(f"Missing lines: {missing_lines}\n")

    except FileNotFoundError as e:
        print(f"Error: {e}. Please check file paths.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")






    try:
            # Read all lines from file2 into a set for efficient lookups
            #with open(file2_path, 'r') as file2:
                # Use strip() to remove leading/trailing whitespace, including newlines
                #file2_lines = set(line.strip() for line in file2)

            print(f"--- Checking lines from '{file2_path}' against '{file1_path}' ---")
            all_lines_present = True
            missing_lines = []

            # Iterate through each line in file2 and check if it is in the set
            with open(file2_path, 'r') as file2:
                for line_num2, line2 in enumerate(file2, 1):
                    #stripped_line = line.strip()
                    if line2 not in file1_lines:
                        print(f"File 2 Line {line_num2} is missing in file 1 --- {line2}")
                        missing_lines.append(line2)
                        all_lines_present = False
                    #else:
                    #    print(f"Line {line_num}: '{stripped_line}' is present.")

            if all_lines_present:
                print("\n**Conclusion:** All lines from file 2 were found in file 1.\n")
            #else:
                #print(f"\n**Conclusion:** Some lines were missing from file 1.\n")
                #print(f"Missing lines: {missing_lines}")

    except FileNotFoundError as e:
        print(f"Error: {e}. Please check file paths.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")










def process_selection(selection, file1_path, file2_path):

        if selection == '1':
            process_symmetrical_comparison(file1_path, file2_path)
        elif selection == '2':
            process_asymmetrical_comparison(file1_path, file2_path)
        else:
            print("Please select a valid option.")
    

def main():
    # Call other functions here
    file_number = 1
    
    exit_script = False

    while not exit_script:
        selection = print_main_menu()
        if selection != 'e':
            file1_path = open_file_dialog(file_number)
            file2_path = open_file_dialog(file_number + 1)
            process_selection (selection, file1_path, file2_path)
        else:
            exit_script = True



if __name__ == "__main__":
    main()
