#GUESSING GAME

# Create all needed variables.
# Set guess variable to null/empty string.
secret_word = "giraffe"
guess = ""
guess_count = 0
guess_limit = 3
out_of_guesses = False

# Go through loop while guess does not equal secret word and not out of guesses.
while guess != secret_word and not(out_of_guesses):
    if guess_count < guess_limit:
        guess = input("Enter guess: ")
        guess_count += 1
    else:
        out_of_guesses = True
    if guess != secret_word and guess_count != 3:
        print("Please try again.")


if out_of_guesses:
    print("You lose!")
else:
    print("You win!")
