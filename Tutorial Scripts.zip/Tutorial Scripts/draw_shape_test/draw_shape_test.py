# DRAW A SHAPE

print("   *")
print("  * *")
print(" *   *")
print("*******")

print("   /\\")
print("  /  \\")
print(" /____\\")
