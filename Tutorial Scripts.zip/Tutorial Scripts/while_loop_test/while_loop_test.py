# WHILE LOOPS

i = 1
# Loop through until i is 10. Print value of i each time.
while i <= 10:
    print(i)
    i = i + 1
    # or
    # i += 1

print("Done with loop.")