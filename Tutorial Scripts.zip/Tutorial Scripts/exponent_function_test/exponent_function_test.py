# EXPONENT FUNCTIONS

#print(2**3)

# This function will allow to take a number and raise it to a specific power.
## ** is used as the power rather than ^.
def raise_to_power(base_num, pow_num):
    result = 1
    for index in range(pow_num):
        result = result * base_num
    return result

print(raise_to_power(2, 3))