# BUILD A TRANSLATOR
# Will take in a word and translate it to another language.

# Giraffe Language
# vowels -> g
# --------------

# dog -> dgg
# cat -> cgt
# ----------------------------------------------------------------------------------------------------------------------

def translate(phrase):
    translation = ""
    for letter in phrase:
        if letter in "AEIOUaeiou":
            # if letter.lower() in "aeiou":
            # if letter.isupper():
            #   translation = translation + "G"
            # else
            #   tranlation = translation + "g"
            translation = translation + "g"
        else:
            translation = translation + letter
    return translation

print(translate(input("Enter a phrase: ")))