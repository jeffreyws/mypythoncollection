# USING VARIABLES

# Data type is a string
character_name = "John"
character_age = "35"

# Data type is a number
# character_age = 35
# character_age = 35.443543

# Data type is a boolean
# is_male = True
# is_male = False

print("There once was a man named " + character_name + ", and")
print("he was " + character_age + " years old")
print("He really liked the name " + character_name + ", " )
print("but didn't like being " + character_age + "." )