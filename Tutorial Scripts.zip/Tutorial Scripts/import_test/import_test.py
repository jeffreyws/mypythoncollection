# IMPORT FUNCTIONS FROM LIBRARY

# Import all functions from math library.
from math import *

# Print the base number elliminating any decimal values.
print(floor(3.7))

# Print the rounded whole number elliminating any decimal values.
print(ceil(3.7))

# Print the square root.
print(sqrt(36))