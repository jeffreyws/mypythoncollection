#from future.moves import tkinter as tk

# Label widget

#label1 = tk.Label(text="Hello, Tkinter")

#label2 = tk.Label(
#    text="Hello, Tkinter",
#    foreground="white",  # Set the text color to white
#    background="black"  # Set the background color to black
#)

#label3 = tk.Label(text="Hello, Tkinter", background="#34A2FE")#\

#label4 = tk.Label(
#    text="Hello, Tkinter",
#    fg="white",
#    bg="black",
#    width=10,
#    height=10
#)

# Create Button
#button = tk.Button(
#    text="Click me!",
#    width=25,
#    height=5,
#    bg="blue",
#    fg="yellow",
#)

# Get user input
#entry = tk.Entry(fg="yellow", bg="blue", width=50)



#label5 = tk.Label(text="Name")
#entry5 = tk.Entry()
#label5.pack()
#entry5.pack()
import tkinter
from tkinter import *
from tkinter import ttk
window = Tk()
window.title("Welcome to TutorialsPoint")
window.geometry('400x400')
window.configure(background = "grey")
a1 = tkinter.StringVar()
b1 = tkinter.StringVar()
a = Label(window ,text = "First Name", fg="black", bg="gray").grid(row = 0,column = 0)
b = Label(window ,text = "Last Name", fg="black", bg="gray").grid(row = 1,column = 0)
c = Label(window ,text = "Email Id", fg="black", bg="gray").grid(row = 2,column = 0)
d = Label(window ,text = "Contact Number", fg="black", bg="gray").grid(row = 3,column = 0)
a1 = Entry(window).grid(row = 0,column = 1)
b1 = Entry(window).grid(row = 1,column = 1)
c1 = Entry(window).grid(row = 2,column = 1)
d1 = Entry(window).grid(row = 3,column = 1)

def clicked():
    res = "Welcome to " + a1
    print(res)

btn = ttk.Button(window ,text="Submit", command = clicked).grid(row=4,column=0)
# Keep app open until exit.
window.mainloop()

