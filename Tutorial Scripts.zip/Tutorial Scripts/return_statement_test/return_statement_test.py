# RETURN STATEMENTS

# A RETURN IS USED WITH FUNCTIONS THAT RETURN INFORMATION TO THE PARENT FUNCTION.

# Create the function that takes a parameter.
# This function is designed to cube a number.
# You can't put code inside a function after the return key word.
def cube(num):
    return num * num * num

# Print the returned value.
#print(cube(4))

# Print the returned value after setting a variable to that value.
result = cube(4)
print(result)


