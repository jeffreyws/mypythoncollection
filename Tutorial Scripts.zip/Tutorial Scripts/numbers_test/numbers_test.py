# WORKING WITH NUMBERS

# Print a number.
print(2)

# Print a decimal number.
print(2.0343)

# Print a negative number.
print(-2.343)

# Print the sum of numbers.
print(2 + 3 + 2.4)

# Print the difference of numbers.
print(10 - 2 - 4.2)

# Print the multiplication of numbers
print(2 * 4 * 2)

# Print the division of numbers
print(20 / 5 / 2)

# Print complex operations
print(3 * 4 + 5)
print(3 * (4 + 5))

# Print the remainder
print(10 % 3)

# Set a number variable
my_num = 5
# Print the value of the number variable.
print(my_num)

# Convert a number to string, concatenate with another string and print.
print(str(my_num) + " is my favorite number")

# Print absolute value of a number.
neg_num = -5
print(abs(neg_num))

# Print result of number raised to a power.
print(pow(5, 2))

# Print the largest number in a list.
print(max(4, 6))

# Print the smallest number in a list.
print(min(4, 6))

# Print the rounded number.
print(round(3.4))
