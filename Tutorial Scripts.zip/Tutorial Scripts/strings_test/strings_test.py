# WORKING WITH STRINGS

print ("Printing a string")

# Insert new line
print ("Inserting a new \nline")

# Escape character, print exact character after \
print ("Escaping \"")
print ("Escaping \\")

# Print string variable contents.
myphrase = "Printing my phrase using a variable."
print (myphrase)
print (myphrase + " Now concatenating another string")

# Makes all characters in string to be lower case.
print (myphrase.lower())
# Makes all characters in string to be upper case.
print (myphrase.upper())

# Determines if all characters are lower case.
print (myphrase.islower())
# Determines if all characters are upper case.
print (myphrase.isupper())

# Turn all characters in string to lower case and then test if all lower case. Returns true.
print (myphrase.lower().islower())
# Turn all characters in string to upper case and then test if all upper case. Returns true.
print (myphrase.upper().isupper())

# Get length of string.
print (len(myphrase))

# Prints first character in the string variable
print (myphrase[0])
# Prints second character in the string variable
print (myphrase[1])

# Return the index of the first specified letter in the string.
# If the specified letter or string does not exist an error is thrown.
print(myphrase.index("P"))
print(myphrase.index("n"))
print(myphrase.index("using"))
# print (myphrase.index("poop"))

# Replace a sub-string of variable with another.
print(myphrase.replace("Printing", "Displaying"))

