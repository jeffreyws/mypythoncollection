# FOR LOOPS
# Loops allows us to loop over different collections of items such as arrays, letters in a string, series of numbers, etc.

# The variable defined (ex. letter) will change for each iteration of the loop.
for letter in "Giraffe Academy":
    print(letter)

# Create an array of names.
friends = ["Jim", "Karen", "Kevin"]

# Loop through the array and print each item.
for friend in friends:
    print(friend)

# Loop through the range of numbers 0 through 10 excluding 10 and print the index.
for index in range(10):
    print(index)

# Loop through the range of numbers 3 through 10 excluding 10 and print the index.
for index in range(3, 10):
    print(index)

# Loop through array and print the index of each friend.
for index in range(len(friends)):
    print(index)

# Loop through array and print each friend referenced by the index.
for index in range(len(friends)):
    print(friends[index])

for index in range(5):
    if index == 0:
        print("First Iteration.")
    else:
        print("Not first iteration.")