# 2D LISTS AND NESTED LOOPS

# Create a list
# number_grid = []


# Create list elements inside a list. (Lists inside a list)
number_grid = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
    [0]
]

# Access elements in the list.
# Index starts at 0 for the elements/"rows".
# Index starts at 0 for the elements/"columns" in each row.
# print(number_grid[0][0])

for row in number_grid:
    for col in row:
        print(col)