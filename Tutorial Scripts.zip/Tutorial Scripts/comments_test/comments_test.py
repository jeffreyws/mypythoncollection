# COMMENTS
# A line in python code that does not get rendered.
# The hash tag (#) symbol or three single quotation marks (''')  is used for comments.
# Comments can explain code.
# Comments can remind the programmer of anything.
# You can comment out code to troubleshoot.

'''This is also a comment but is not normally used for comments.'''


