# DICTIONARIES
# A dictionary is special structure that allows us to store information in key value pairs.
# You can access a specific piece of information inside the dictionary you can refer to it by it's key.

# Convert a 3 letter month abbreviation into the full month name
# ex: Jan -> January

monthConversions = {
    "Jan": "January",
    "Feb": "February",
    "Mar": "March",
    "April": "April",
    "May": "May",
    "Jun": "June",
    "Jul": "July",
    "Aug": "August",
    "Sept": "September",
    "Oct": "October",
    "Nov": "November",
    "Dec": "December",
}

# Print the proper full month name using the 3 letter abreviation.
print(monthConversions["Nov"])
print(monthConversions.get("Dec"))
print(monthConversions.get("Luv", "Not a valid key."))
