# IF STATEMENTS
# Set two boolean variables to use in if statement
is_male = False
is_tall = True

if is_male:
    print("You are a male.")
else:
    print("You are a female.")

if is_male or is_tall:
    print("You are a male or tall or both.")
else:
    print("You are neither a male or tall.")

if is_male and is_tall:
    print("You are a tall male.")
else:
    print("You are either not male or not tall or both.")


if is_male and is_tall:
    print("You are a tall male.")
elif is_male and not(is_tall):
    print("You are a short male.")
elif not(is_male) and is_tall:
    print("You are not a male but are tall.")
else:
    print("You are not a male and not tall.")

# Return the larger of 3 numbers provided.
def max_num(num1, num2, num3):
    if num1 >= num2 and num1 >= num3:
        return num1
    elif num2 >= num1 and num2 >= num3:
        return num2
    else:
        return num3

# Call the max_num function and print the largest value in the arguments passed.
print(max_num(3, 4, 5))

# COMPARISON OPERATORS
# == means equal
# > means greater than
# < means less than
# >= means greater than or equal to
# <= means less than or equal to
# != means not equal
# !> means not greater than
# !< means not less than

