# TRY EXCEPT
# Errors can be encountered in python scripts.
# Exceptions can be used to return errors to prevent the script from failing.

try:
    number = int(input("Enter a number: "))
    print(number)
except:
    print("Invalid input.")