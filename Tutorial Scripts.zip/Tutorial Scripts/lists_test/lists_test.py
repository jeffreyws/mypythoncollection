# USING LISTS

# Create a list
friends = ["Kevin", "Karen", "Jim", "Oscar", "Toby", "Oscar"]
# Lists can have strings, numbers or booleans.
# friends = ["Kevin", 2, False]

# Print the contents of the list.
print(friends)

# Print the contents of the list at index specified.
print(friends[1])

# Print the last element in the list. Indexes start at -1 when going from last to first element in list.
print(friends[-1])

# Print all element in list starting with index specified.
print(friends[1:])

# Print all element in list within a range of indexes minus 1 (the second index is not included).
print(friends[1:3])

# Modify/Replace the element at index specified.
friends[1] = "Mike"
print(friends[1])

# Using functions with lists
lucky_numbers = [4, 8, 15, 42, 23, 13]

# Join a list to another list. Then print the list.
friends.extend(lucky_numbers)
print(friends)

# Add a new element to the end of the list. Then print the list.
friends.append("Joe")
print(friends)

# Insert a new element at index specified. Then print the list.
friends.insert(1, "Kelly")
print(friends)

# Remove an element from the list. Then print the list.
friends.remove("Jim")
print(friends)

# Clear the contents of the list.
# friends.clear()
# print(friends)

# Remove the last element from the list. Then print the list.
friends.pop()
print(friends)

# Print the index for the element specified. If the element doesn't exist, an error will be thrown.
print(friends.index("Kevin"))

# Print the number of times the element is in the list.
print(friends.count("Oscar"))

# Sort the list and then print.
lucky_numbers.sort()
print(lucky_numbers)

# Reverse a list.
lucky_numbers.reverse()
print(lucky_numbers)

# Copy a list.
friends2 = [friends.copy()]
print(friends2)