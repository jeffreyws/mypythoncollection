# USER INPUT

# Request user to enter name and age. Then print a welcome message.
user_name = input("Enter your name: ")
user_age = input("Enter your age: ")
print("Hello " + user_name + "! You are " + user_age + ".")
