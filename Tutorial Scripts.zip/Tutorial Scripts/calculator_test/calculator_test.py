# BUILD A BASIC CALCULATOR

# Get two numbers from the user. These numbers will be strings by default.
num1 = input("Enter a number: ")
num2 = input("Enter another number: ")

# Convert strings to integers and add them storing them into variable result. Then print the result.
# Int can only be whole numbers. Float can be whole number or decimal number.
# result = int(num1) + int(num2)
# print(result)

result = float(num1) + float(num2)
print(result)