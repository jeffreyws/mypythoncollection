# TUPLES

# A tuple is a type of data structure.
# It is a container where we can store different values.
# It is similar to a list.
# A tuple is immutable, meaning once it is created, it can't be changed.


# Create a tuple.
coordinates = (4, 5)
print(coordinates[0])
print(coordinates[1])