import os

# READ FILE

# Open file with read access. Store contents of file in a variable.
file_path = os.path.join(os.path.dirname(__file__), 'employees.txt')
employee_file = open(file_path, "r")

# Read each line of file into a variable
content = employee_file.readlines()

#if employee_file.readable():
    # print(employee_file)
    # print (employee_file.readline())

# Read and print first line of employee_file.
# print(employee_file.readline())
# Read and print next line of employee_file.
# print(employee_file.readline())

# Print the contents of the variable/array.
print(content)
# Print the line at the specified array index.
print(content[1])

#for employee in employee_file.readlines:
#   print(employee_file.readlines())

# Open file with read and write access. Store contents of file in a variable.
# employee_file = open("employees.txt", "r+")

# Open file with write access. Store contents of file in a variable.
# employee_file = open("employees.txt", "w")

# Open file with append access. Store contents of file in a variable.
# employee_file = open("employees.txt", "a")

employee_file.close()