# CREATE A MAD LIB GAME USING INPUTS

print("Roses are red.")
print("Violets are blue.")
print("I love you.")

color = input("Enter a color: ")
plural_noun = input("Enter a plural noun: ")
celebrity = input("Enter a celebrity: ")

print("Roses are " + color +  ".")
print(plural_noun + " are blue.")
print("I love " + celebrity + ".")