# FUNCTIONS

# Create the function. Contents must be indented.
# Use lower case for function name.

def say_hi():
    print("Hello User")

# Call the function
say_hi()



def say_hi_again(name, age):
    print("Hello " + name + ", you are " + age)

# Call the function
say_hi_again("Mike", "35")
say_hi_again("Steve", "70")


